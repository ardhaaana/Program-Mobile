package com.pmobile.uaspbo1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class hasil_beli extends AppCompatActivity {
    TextView nama1, jumlah1, datalogam1, lihat1, ht1,ht2,ht3, ht4, ht5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil_beli);


        nama1 = findViewById(R.id.nama1);
        jumlah1 = findViewById(R.id.jumlah1);
        datalogam1 = findViewById(R.id.dataLogam1);
        lihat1 = findViewById(R.id.lihat);
        ht1 = findViewById(R.id.ht1);
        ht2 = findViewById(R.id.ht2);
        ht3 = findViewById(R.id.ht3);
        ht4 = findViewById(R.id.ht4);
        ht5 = findViewById(R.id.ht5);


        Intent hasil = getIntent();
        nama1.setText( hasil.getStringExtra("NAMA"));
        jumlah1.setText( hasil.getStringExtra("JUMLAH"));
        datalogam1.setText(hasil.getStringExtra("DTLOGAM"));
        lihat1.setText(hasil.getStringExtra("LIHAT"));
        ht1.setText(hasil.getStringExtra("HITUNG1"));
        ht2.setText(hasil.getStringExtra("HITUNG2"));
        ht3.setText(hasil.getStringExtra("HITUNG3"));
        ht4.setText(hasil.getStringExtra("HITUNG4"));
        ht5.setText(hasil.getStringExtra("HITUNG5"));

        String datacheck = hasil .getStringExtra("Data");
        lihat1.setText(datacheck);
    }
}