package com.pmobile.uaspbo1;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class recyclerAdapter extends RecyclerView.Adapter<recyclerAdapter.ViewHolder> {
    ArrayList<IsiArray> list_ra;
    public recyclerAdapter(ArrayList<IsiArray> list_ra) {
        this.list_ra = list_ra;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //inflate Layout list_data
        View v = LayoutInflater.from(parent.getContext()).
                inflate(R.layout.list_data, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        IsiArray cls = list_ra.get(position);
        //atur gambar dengan glide supaya ringan ketika di-Load
        Glide.with(holder.itemView.getContext())
                .load(cls.getFoto())
                .into(holder.imgView);
        holder.txtNama.setText(cls.getNama());
        holder.txtDeskripsi.setText(cls.getDeskripsi());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //menambahkan intent
                Intent intent = new Intent(holder.itemView.getContext(),fragment_shop.class);
                holder.itemView.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        //mengembalikan nilai arraylist
        return list_ra.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        //deklarasi widget
        ImageView imgView;
        TextView txtNama, txtDeskripsi;

        public ViewHolder(@NonNull View itemView) { //constructor
            super(itemView);
            imgView = itemView.findViewById(R.id.imgView);
            txtNama = itemView.findViewById(R.id.txtNama);
            txtDeskripsi = itemView.findViewById(R.id.txtDesc);
        }
    }
}
