package com.pmobile.uaspbo1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class layout_menu extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout_menu);

        //loading the default fragment
        loadFragment(new fragment_catalog());

        //getting bottom navigation view and attaching the listener
        BottomNavigationView navigation = findViewById(R.id.menu_bwh);
        navigation.setOnNavigationItemSelectedListener(this);
    }

        private boolean loadFragment(Fragment fragment) {
            //switching fragment
            if (fragment != null) {
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.framelyt, fragment)
                        .commit();
                return true;
            }
            return false;
        }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment = null;

        switch (item.getItemId()) {
            case R.id.catalog:
                fragment = new fragment_catalog();
                break;

            case R.id.shop:
                fragment = new fragment_shop();
                break;

            case R.id.profile:
                fragment = new fragment_profile();
                break;
        }
        return loadFragment(fragment);
    }
}