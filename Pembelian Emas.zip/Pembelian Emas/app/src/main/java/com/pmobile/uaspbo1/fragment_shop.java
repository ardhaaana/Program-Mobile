package com.pmobile.uaspbo1;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

public class fragment_shop extends Fragment {
    private EditText namabeli, jumlahbeli, uang;
    TextView lihatbeli;
    private Spinner dataLogambeli;
    private RadioButton rbbeli;
    private CheckBox check1beli, check2beli, check3beli, check4beli, check5beli;
    private Button prosesbeli;
    private static final String CHANNEL_ID = "MyAppl";
    private static final int NOTIF_ID = 1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_fragment_shop, container, false);
        namabeli = view.findViewById(R.id.namabeli);
        jumlahbeli = view.findViewById(R.id.jumlahbeli);
        dataLogambeli = view.findViewById(R.id.dataLogambeli);
        check1beli = view.findViewById(R.id.check1beli);
        check2beli = view.findViewById(R.id.check2beli);
        check3beli = view.findViewById(R.id.check3beli);
        check4beli = view.findViewById(R.id.check4beli);
        check5beli = view.findViewById(R.id.check5beli);
        rbbeli = view.findViewById(R.id.rbbeli);
        uang = view.findViewById(R.id.uang);
        prosesbeli = view.findViewById(R.id.prosesbeli);
        lihatbeli = view.findViewById(R.id.lihat);

        prosesbeli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuffer hasil= new StringBuffer();
                //append adalah ditambahkan

                int hitung1 = 0;
                int hitung2 = 0;
                int hitung3 = 0;
                int hitung4 = 0;
                int hitung5 = 0;
                int jh;
                int u;

                jh = Integer.parseInt(jumlahbeli.getText().toString());
                u = Integer.parseInt(uang.getText().toString());


                if(check1beli.isChecked())
                {
                    hasil.append("\n Harga (Rp. 2,750,000)");
                    hitung1 = u - (jh * 2750000);

                }
                if(check2beli.isChecked())
                {
                    hasil.append("\n Harga (Rp. 4,550,000)");
                    hitung2 = u - (jh * 4550000);

                }
                if(check3beli.isChecked())
                {
                    hasil.append("\n Harga (Rp. 9,045,000)");
                    hitung3 = u - (jh * 9045000);

                }
                if(check4beli.isChecked())
                {
                    hasil.append("\n Harga (Rp. 22,487,000)");
                    hitung4 = u - (jh * 22487000);

                }
                if(check5beli.isChecked())
                {
                    hasil.append("\n Harga (Rp. 89,712,000)");
                    hitung5 = u - (jh * 89712000);

                }
                if(rbbeli.isChecked())
                {
                    hasil.append("\n Selesai");

                }


                Intent intentExtra = new Intent(fragment_shop.this.getActivity(), hasil_beli.class);
                //pengiriman data menggunakan objek intent extra
                intentExtra.putExtra("NAMA",namabeli.getText().toString());
                intentExtra.putExtra("JUMLAH",jumlahbeli.getText().toString());
                intentExtra.putExtra("DTLOGAM",dataLogambeli.getSelectedItem().toString());
                intentExtra.putExtra("HITUNG1",String.valueOf(hitung1));
                intentExtra.putExtra("HITUNG2",String.valueOf(hitung2));
                intentExtra.putExtra("HITUNG3",String.valueOf(hitung3));
                intentExtra.putExtra("HITUNG4",String.valueOf(hitung3));
                intentExtra.putExtra("HITUNG5",String.valueOf(hitung3));


                String datacheck = hasil.toString();
                intentExtra.putExtra("Data", datacheck);

                startActivity(intentExtra);

                NotificationManager notificationManager = (NotificationManager) getActivity().getSystemService(Context.NOTIFICATION_SERVICE);

                Notification.Builder notifBuilder = new Notification.Builder(fragment_shop.this.getActivity())
                        .setContentTitle("Selamat")
                        .setContentText("Proses Beli Berhasil")
                        .setSmallIcon(R.drawable.ic_launcher_background)
                        .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                        .setPriority(Notification.PRIORITY_HIGH)
                        .setAutoCancel(true);
                //jalankan/aktifkan
                notificationManager.notify(NOTIF_ID, notifBuilder.build());
            }
        });

        return view;
    }
}