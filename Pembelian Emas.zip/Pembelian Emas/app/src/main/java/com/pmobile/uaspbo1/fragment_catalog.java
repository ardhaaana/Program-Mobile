package com.pmobile.uaspbo1;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class fragment_catalog extends Fragment{

    RecyclerView rv;
    ArrayList<IsiArray> list;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
            View view = inflater.inflate(R.layout.activity_fragment_catalog, container, false);

        RecyclerView rv= (RecyclerView) view.findViewById(R.id.recyclerView);
        rv.setHasFixedSize(true); //supaya saat ada perubahan data, ukuran rv bisa menyesuaikan

        list = new ArrayList<>();
        list.addAll(isiData.getArrayData());

        //menampilkan hasilnya
        rv.setLayoutManager(new LinearLayoutManager(this.getActivity()));
        recyclerAdapter adapter = new recyclerAdapter(list);
        rv.setAdapter(adapter);

        return view;




    }
}