package com.pmobile.uaspbo1;

import java.util.ArrayList;

public class isiData {
    public static String[] dataNama = {
            "Logam Mulia Emas Batangan 3gr",
            "Logam Mulia Emas Batangan 5gr",
            "Logam Mulia Emas Batangan 10gr",
            "Logam Mulia Emas Batangan 25gr",
            "Logam Mulia Emas Batangan 100gr",
            "Logam Mulia Perak Batangan Murni 99.95%"
    };

    public static String[] dataDeskripsi = {
            "Rp. 2,750,000",
            "Rp. 4,550,000",
            "Rp. 9,045,000",
            "Rp. 22,487,000",
            "Rp. 89,712,000",
            "Rp. 3.925.000"
    };

    public static String[] dataFoto = {

            "https://www.logammulia.com/uploads/ngc_master_item_variant/5ef98e0ff398b_20200629134535-1.jpg",
            "https://www.logammulia.com/uploads/ngc_master_item_variant/5ef98e21610e4_20200629134553-1.jpg",
            "https://www.logammulia.com/uploads/ngc_master_item_variant/5ef98e3e92754_20200629134622-1.jpg",
            "https://www.logammulia.com/uploads/ngc_master_item_variant/5ef98e5053965_20200629134640-1.jpg",
            "https://www.logammulia.com/uploads/ngc_master_item_variant/5ef98e7333701_20200629134715-1.jpg",
            "https://www.logammulia.com/uploads/ngc_master_item/5be955801d91d_20181112172712-2.jpg"

    };

    public static ArrayList<IsiArray> getArrayData(){
        ArrayList<IsiArray> list_array = new ArrayList<>();
        //Load data array
        for(int i = 0; i< dataNama.length; i++ ){
            //isi setter dari clsPojo
            IsiArray IsiArray = new IsiArray();
            IsiArray.setNama(dataNama[i]);
            IsiArray.setDeskripsi(dataDeskripsi[i]);
            IsiArray.setFoto(dataFoto[i]);

            list_array.add(IsiArray);
        }

        //mengembalikan isi arraylist
        return list_array;
    }
}
